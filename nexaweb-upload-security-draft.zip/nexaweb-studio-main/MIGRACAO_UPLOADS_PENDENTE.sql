-- NexaWeb: base de controle de anexos (REVISAR antes de executar).
-- Esta migração NÃO foi executada. Não habilita quotas até o endpoint chamar as funções abaixo.
-- Limites planejados: 5 arquivos / 50 MiB por projeto; 15 MiB por arquivo.

create table if not exists public.project_attachments (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  storage_path text not null unique,
  mime_type text not null check (mime_type in ('image/jpeg', 'image/png', 'image/webp')),
  size_bytes bigint not null check (size_bytes > 0 and size_bytes <= 15728640),
  state text not null default 'PENDING' check (state in ('PENDING', 'READY', 'DELETING', 'DELETED', 'DELETION_FAILED')),
  reservation_expires_at timestamptz not null default (now() + interval '20 minutes'),
  cleanup_attempts integer not null default 0 check (cleanup_attempts >= 0),
  cleanup_lease_token uuid,
  cleanup_lease_expires_at timestamptz,
  last_cleanup_error text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists project_attachments_project_state_idx
  on public.project_attachments(project_id, state);
create index if not exists project_attachments_cleanup_idx
  on public.project_attachments(state, reservation_expires_at)
  where state in ('PENDING', 'DELETING', 'DELETION_FAILED');

alter table public.project_attachments enable row level security;
-- Sem políticas para anon/authenticated: operações devem passar por API server-side/service role.

create or replace function public.reserve_project_attachment(
  p_project_id uuid,
  p_storage_path text,
  p_mime_type text,
  p_size_bytes bigint
) returns jsonb
language plpgsql security definer set search_path = public, pg_temp
as $$
declare
  v_count bigint;
  v_bytes bigint;
  v_id uuid;
begin
  if p_size_bytes is null or p_size_bytes <= 0 or p_size_bytes > 15728640 then
    return jsonb_build_object('ok', false, 'reason', 'FILE_SIZE');
  end if;
  if p_mime_type not in ('image/jpeg', 'image/png', 'image/webp') then
    return jsonb_build_object('ok', false, 'reason', 'MIME');
  end if;
  if p_storage_path not like ('briefings/' || p_project_id::text || '/%') then
    return jsonb_build_object('ok', false, 'reason', 'PATH');
  end if;

  -- Serializa as reservas do mesmo projeto para impedir duas reservas concorrentes acima do limite.
  perform 1 from public.projects where id = p_project_id for update;
  if not found then return jsonb_build_object('ok', false, 'reason', 'PROJECT_NOT_FOUND'); end if;

  select count(*), coalesce(sum(size_bytes), 0)
    into v_count, v_bytes
    from public.project_attachments
   where project_id = p_project_id and state in ('PENDING', 'READY', 'DELETION_FAILED');

  if v_count >= 5 then return jsonb_build_object('ok', false, 'reason', 'FILE_COUNT'); end if;
  if v_bytes + p_size_bytes > 52428800 then return jsonb_build_object('ok', false, 'reason', 'PROJECT_QUOTA'); end if;

  insert into public.project_attachments(project_id, storage_path, mime_type, size_bytes, state)
  values (p_project_id, p_storage_path, p_mime_type, p_size_bytes, 'PENDING')
  returning id into v_id;
  return jsonb_build_object('ok', true, 'attachment_id', v_id);
exception when unique_violation then
  return jsonb_build_object('ok', false, 'reason', 'DUPLICATE_PATH');
end;
$$;

create or replace function public.finish_project_attachment(p_attachment_id uuid)
returns boolean language plpgsql security definer set search_path = public, pg_temp
as $$
begin
  update public.project_attachments
     set state = 'READY', reservation_expires_at = now() + interval '100 years', updated_at = now()
   where id = p_attachment_id and state = 'PENDING';
  return found;
end;
$$;

create or replace function public.release_project_attachment(p_attachment_id uuid)
returns boolean language plpgsql security definer set search_path = public, pg_temp
as $$
begin
  update public.project_attachments
     set state = 'DELETING', updated_at = now()
   where id = p_attachment_id and state = 'PENDING';
  return found;
end;
$$;

revoke all on function public.reserve_project_attachment(uuid, text, text, bigint) from public, anon, authenticated;
revoke all on function public.finish_project_attachment(uuid) from public, anon, authenticated;
revoke all on function public.release_project_attachment(uuid) from public, anon, authenticated;
grant execute on function public.reserve_project_attachment(uuid, text, text, bigint) to service_role;
grant execute on function public.finish_project_attachment(uuid) to service_role;
grant execute on function public.release_project_attachment(uuid) to service_role;
